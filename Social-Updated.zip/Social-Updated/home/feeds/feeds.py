from  home.models import Following, Post,Blog
from datetime import datetime, timedelta



def feedalgo(id,flag):
    #Fetch the Users followings
    followings=Following.objects.filter(Bywho=id)

    
    flst=[]
    for i in followings:
        try:
            flst.append(i.whom.id)
        except:
            pass

    time_threshold = datetime.now() - timedelta(hours=3)

    if flag == 0:
        # qs=Post.objects.filter(UID__in=flst).filter(Time__lt=time_threshold).order_by('-Time')
        qs=Post.objects.filter(UID__in=flst)
    
#Use nested for loops for out the data


    return(qs)

def blogalgo(id):
    #Fetch the Users followings
    followings=Following.objects.filter(Bywho=id)

    
    flst=[]
    for i in followings:
        try:
            flst.append(i.whom.id)
        except:
            pass

    time_threshold = datetime.now() - timedelta(hours=3)

  #  print(time_threshold)

    qs=Blog.objects.filter(user__in=flst).filter(Time__lt=time_threshold).order_by('-Time')
    

#Use nested for loops for out the data


    return(qs)

def suggestalgo(id,flag):
    #Fetch the Users followings
    followings=Following.objects.filter(Bywho=id)

    
    flst=[]
    for i in followings:
        try:
            flst.append(i.whom.id)
        except:
            pass

    time_threshold = datetime.now() - timedelta(hours=3)

   # print(time_threshold)

    if flag == 0:
        qs=Post.objects.exclude(UID__in = flst).filter(Time__lt=time_threshold).order_by('-Time')
    
   

#Use nested for loops for out the data


    return(qs)


    
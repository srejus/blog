import requests

content="Hello World!"
usr = 1

url = f'http://127.0.0.1:8000/bot_post/{content}/{usr}'
myobj = {'content': 'somevalue','uid':'1'}

x = requests.get(url, json = myobj)

fl = open('file.html','a')
fl.write(x.text)
fl.close()

print(x.text)
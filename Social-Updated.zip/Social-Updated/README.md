# social-media-website
This is a social media website with Django backend and HTML CSS JS frontend.
for more about the packages used i also requirements.txt file.

Key features of the Website

->user can follow other people.
->News feed is load based on the time which the post is created.

from pyexpat import model
from django.db import models
from django.db.models.deletion import CASCADE

# Create your models here.

class Language(models.Model):
    language=models.CharField(max_length=100)
    desc = models.TextField(null=True,blank=True)

    def __str__(self):
        return self.language

class Chapter(models.Model):
    lang=models.ForeignKey(Language,on_delete=models.CASCADE,related_name='lang')
    title=models.CharField(max_length=100)
    short_desc=models.CharField(max_length=100,null=True,blank=True)
    content=models.TextField()
    keywords=models.TextField(null=True,blank=True)
    slug=models.CharField(max_length=200,null=False,blank=False,unique=True)

    def __str__(self):
        return self.title


class NewsLetter(models.Model):
    email=models.CharField(max_length=100)

    def __str__(self):
        return self.email

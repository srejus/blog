from django.shortcuts import render
from . models import *

# Create your views here.
def index(request):
    lng = Language.objects.all()
    return render(request,'index.html',{'lang':lng})

def learn(request,langs):
    try:
        lng=Language.objects.get(language=langs)
        x=Chapter.objects.filter(lang=lng)
        return render(request,'chapters.html',{'res':x,'lan':langs})
    except:
        return render(request,'chapters.html')

def reader(request,id,slug=None):
    x=Chapter.objects.get(id=id)
    return render(request,'reader.html',{'res':x})

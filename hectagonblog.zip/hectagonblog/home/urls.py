from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index'),
    path('learn/<str:langs>',views.learn,name='learn'),
    path('<int:id>/<str:slug>',views.reader,name='reader'),
]
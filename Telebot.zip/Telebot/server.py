from email import message
from reply import make_reply


from bot import telegram_chatbot

update_id = None

bot = telegram_chatbot("config.cfg")



while True:
    print("Bot Running..")
    updates = bot.get_updates(offset=update_id)
    updates = updates["result"]
    if updates:
        for item in updates:
            update_id = item["update_id"]
            try:
                message = item["message"]["text"]
            except:
                message = None
            from_ = item["message"]["from"]["id"]
            reply = make_reply(message)
            bot.send_message(reply,from_)
import random


#Random Replys

kazhicho = ["Am nio","Am","Noo","illa"]
food = ["Chorum Chickenum","Chorum morum muttem","chorundu","choru thoran achar","Biriyani kazhichallo njan","Friedrice and chicken"]

rply = ["Mm","Mmm","eee","Am","Am eee"]
rand_qns = ["Ellarum Endhey?","Food Kazhicho","Enthedukuva","Evida","Satyam para arodu chattuva Whats appil","Para","Ni para","Eda","Da"]

kiss = ["Ummmmmmmmma","Ummmmma","Ayyeda","Tharooolaa","Eda Kallaa","eeee","Ella","Arelum undo adut?"]

enthedukuva = ["Ente chakkarayod minduvaanallo","Chumma irikkuva njan","Chumma ingane irikannu","Chaaya kudikuva","Ente muthinod minduvalle njan","Njn ente hus nod minduva","Njan ente chekkanod minduva"]
call = ["Enthoo","Njan ivde und","Aha vanno","Hi","Chakkare"]

bye = ["Bye","Am","tata","Am tata pinne kaanam","Vegam varane muthe","Vegam varuvo?","Evide pova?","mm ok"]


def make_reply(msg):
    msg = msg.lower()
    if msg == "hai" or msg == "hi" or msg == "hello" or msg == "hlo":
        reply = "Hi"

    elif msg == "athu" or msg == "muthe" or msg == "molu" or msg == "da" or msg =="di" or msg == "d":
        reply = random.choice(call)

    elif "enthedukuva" in msg:
        reply = random.choice(enthedukuva)

    elif "kazhicho" in msg or msg == "chorundo":
        reply = random.choice(kazhicho)
    
    elif "entha kazhiche" in msg:
        reply = random.choice(food)

    elif "pinneyo" in msg or "pinne enna" in msg or "para" in msg:
        reply = random.choice(rand_qns)

    elif "enthe" in msg:
        reply = "Onnulla"
    
    elif msg ==  "umma tharuvo" or msg == "oru umma tharuvo" or msg == "orumma thaa" or msg == "oru umma thaa" or msg == "orumma tharuvo":
        reply = random.choice(kiss)

    elif msg == "illa arula adut thaa" or msg == "illa arula adut":
        reply = "Ummmmmmmmmmmaaaaaaa...."

    elif msg == "podi kalli" or msg == "podi" or msg == "edi kalli":
        reply = random.choice(rply)

    elif msg == "entho" or msg == "endho":
        reply = random.choice(rand_qns)

    elif msg == "boradikuva" or msg == "enik boradikuva":
        reply = "Boradi maaran athu kochinu oru sadanam tharatte?"
    
    elif msg == "Am entha thaa":
        reply = "Ummmmmma"
    
    elif msg == "ee samayatho" or msg == "ee tymilo" or msg == "eppozho" or msg == "ippozho" or msg == "ipozho":
        reply = "Am athinentha"
    
    elif "bye" in msg:
        reply = random.choice(bye)
    
    elif msg == "ellarum endhey" or msg == "elarum endhey":
        reply = "Ivde und"
    
    elif msg == "athentha kazhikathe" or msg == "athentha chorunnathe":
        reply = "Tym aavanathalle ollu"
    else:
        reply = random.choice(rply)
    return reply

